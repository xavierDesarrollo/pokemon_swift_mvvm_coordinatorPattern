//
//  AppCoordinator.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation
import UIKit

class AppCoordinator : Coordinator {
    var parentCoordinator: Coordinator?
    var children: [Coordinator] = []
    var navigationController: UINavigationController
    init(navigationController : UINavigationController) {
        self.navigationController = navigationController
    }
    func start() {
        goToPokemonsList()
    }
    
    let storyboard = UIStoryboard.init(name: "LaunchScreen", bundle: .main)
    func goToPokemonsList() {
        let pokemonListViewModel = PokemonListViewModel.init()
        pokemonListViewModel.coordinator = self
        navigationController.pushViewController(PokemonListViewController(viewModel: pokemonListViewModel), animated: true)
    }
    
    func goToPokemonDetail(pokemon: Pokemon) {
        let pokemonDetailViewModel = PokemonDetailViewModel.init()
        pokemonDetailViewModel.coordinator = self
        pokemonDetailViewModel.pokemon = pokemon
        navigationController.pushViewController(PokemonDetailViewController(viewModel: pokemonDetailViewModel), animated: true)
    }
}
