//
//  ViewState.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation

enum ViewState {
    case idle
    case loading
    case success
    case error(Error)
}
