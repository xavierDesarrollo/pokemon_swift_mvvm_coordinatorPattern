//
//  UITableViewCell.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation
import UIKit

public extension UITableViewCell {
    
    static var defaultIdentifier: String {
        return String(describing: self)
    }
}
