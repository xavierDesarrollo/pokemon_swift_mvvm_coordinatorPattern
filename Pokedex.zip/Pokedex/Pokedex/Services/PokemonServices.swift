//
//  PokemonListServices.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation

final class PokemonServices {

    private enum ApiURL {
        case base
        case baseImage
        
        var baseURL: String {
            switch self {
                case .base: return "https://pokeapi.co/api/v2/pokemon"
                case .baseImage: return "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon"
            }
        }
    }

    private enum Endpoint {
        case pokemonList

        var path: String {
            switch self {
            case .pokemonList: return "?limit=151&offset=0"
            }
        }

        var url: String {
            switch self {
                case .pokemonList: return "\(ApiURL.base.baseURL)\(path)"
            }
        }

    }

    static func getPokemons(completion: @escaping (Result<Pokemons, Error>) -> Void) {
        guard Reachability.isConnectedToNetwork(),
              let url = URL(string: Endpoint.pokemonList.url) else {
                  completion(.failure(CustomError.noConnection))
                  return
              }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                print(#function, "Request: \(request)\nError: \(error)")
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(CustomError.noData))
                return
            }

            do {
                let pokemons = try JSONDecoder().decode(Pokemons.self, from: data)
                completion(.success(pokemons))
            } catch let error {
                print(#function, "Request: \(request)\nError: \(error)")
                completion(.failure(error))
            }
            
        }.resume()
    }
    
    static func getPokemonDetail(url: String, completion: @escaping (Result<PokemonDetail, Error>) -> Void) {
        guard Reachability.isConnectedToNetwork(),
              let url = URL(string: url) else {
                  completion(.failure(CustomError.noConnection))
                  return
              }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                print(#function, "Request: \(request)\nError: \(error)")
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(CustomError.noData))
                return
            }

            do {
                let pokemonDetail = try JSONDecoder().decode(PokemonDetail.self, from: data)
                completion(.success(pokemonDetail))
            } catch let error {
                print(#function, "Request: \(request)\nError: \(error)")
                completion(.failure(error))
            }

        }.resume()
    }
    
    static func getImageUrl(url: String) -> String {
        return "\(ApiURL.baseImage.baseURL)/\(String(url.split(separator: "/")[5])).png"
        //return "\(url.replacingOccurrences(of: ApiURL.base.baseURL, with: ApiURL.baseImage.baseURL).removeLast()).png"
    }
}
