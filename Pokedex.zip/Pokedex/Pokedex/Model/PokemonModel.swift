//
//  PokemonModel.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation

struct Pokemons: Codable {
    let count: Int?
    let next: String?
    let previous: String?
    let results: [Pokemon]?
}

struct Pokemon: Codable {
    let name: String
    let url: String
}

struct PokemonDetail: Codable {
    //Maquetación respuesta detalle pokemon
}


