//
//  PokemonDetailViewModel.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation

final class PokemonDetailViewModel {
    weak var delegate: RequestDelegate?
    weak var coordinator: AppCoordinator!
    var pokemon: Pokemon!
    
    private var state: ViewState {
        didSet {
            self.delegate?.didUpdate(with: state)
        }
    }

    init() {
        self.state = .loading
    }
}
