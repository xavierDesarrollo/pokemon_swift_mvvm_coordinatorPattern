//
//  PokemonDetailViewModel.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation

final class PokemonDetailViewModel {
    weak var delegate: RequestDelegate?
    weak var coordinator: AppCoordinator!
    var pokemon: Pokemon!
    var pokemonDetail: PokemonDetail!
    
    private var state: ViewState {
        didSet {
            self.delegate?.didUpdate(with: state)
        }
    }

    init() {
        self.state = .loading
    }
}

// MARK: - Service
extension PokemonDetailViewModel {
    func loadData() {
        self.state = .loading
        PokemonServices.getPokemonDetail(url: pokemon.url) { result in
            switch result {
            case let .success(pokemonDetail):
                self.pokemonDetail = pokemonDetail
                self.state = .success
            case let .failure(error):
                self.pokemonDetail = nil
                self.state = .error(error)
            }
        }
    }
    
    func getInfo() -> String {
        return PokemonServices.getImageUrl(url: pokemon.url)
    }
}
