//
//  PokemonListViewModel.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation

final class PokemonListViewModel {
    weak var delegate: RequestDelegate?
    weak var coordinator : AppCoordinator!

    private var state: ViewState {
        didSet {
            self.delegate?.didUpdate(with: state)
        }
    }

    private var pokemons: [Pokemon] = []
    private var filteredPokemons: [Pokemon] = []
    private var selectedText: String = "" {
        didSet {
            self.filterByName()
        }
    }

    init() {
        self.state = .loading
    }
}

// MARK: - DataSource
extension PokemonListViewModel {
    var numberOfItems: Int {
        filteredPokemons.count
    }

    func getInfo(for indexPath: IndexPath) -> (name: String, imageUrl: String?) {
        let pokemon = filteredPokemons[indexPath.row]
        return (pokemon.name, PokemonServices.getImageUrl(url: pokemon.url))
    }
}

// MARK: - Service
extension PokemonListViewModel {
    func loadData() {
        self.state = .loading
        PokemonServices.getPokemons { result in
            switch result {
            case let .success(pokemons):
                self.pokemons = pokemons.results!
                self.filteredPokemons = pokemons.results!
                self.state = .success
            case let .failure(error):
                self.pokemons = []
                self.filteredPokemons = []
                self.state = .error(error)
            }
        }
    }
    
    func filterByName(text: String) {
        self.selectedText = text
    }
}

// MARK: - Filter Data
private extension PokemonListViewModel {
    func filterByName() {
        if selectedText == "" {
            self.filteredPokemons = pokemons
            self.state = .success
            return
        }
        self.filteredPokemons = self.pokemons.filter { $0.name.contains(self.selectedText.lowercased()) }
        self.state = .success
    }
}

// MARK: - Coordinator
extension PokemonListViewModel {
    func showDetail(indexPath: IndexPath) {
        coordinator.goToPokemonDetail(pokemon: filteredPokemons[indexPath.row])
    }
}

