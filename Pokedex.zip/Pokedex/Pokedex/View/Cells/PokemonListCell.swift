//
//  PokemonListViewCell.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation
import UIKit
import SnapKit
import Kingfisher

final class PokemonListCell: UITableViewCell {
    // MARK: - Properties
    private lazy var mainStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.layer.cornerRadius = 20
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .equalSpacing
        stackView.spacing = 10.0
        return stackView
    }()

    private lazy var titleLabel: UILabel = {
        let label = UILabel()       
        label.font = UIFont.boldSystemFont(ofSize: 16.0)
        label.textColor = .black
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var pokemonImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = #imageLiteral(resourceName: "pokemon-placeholder")
        return imageView
    }()

    // MARK: - Initialization
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        self.backgroundColor = .white
        configureLayout()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        self.pokemonImageView.image = nil
        self.titleLabel.text = nil
    }
}

// MARK: - Setup UI
private extension PokemonListCell {
    func configureLayout() {
        backgroundColor = .white
        
        contentView.addSubview(mainStackView)
        
        mainStackView.snp.makeConstraints {
            $0.edges.equalToSuperview().inset(16.0)
        }
        
        mainStackView.addArrangedSubview(titleLabel)
        
        titleLabel.snp.makeConstraints {
            $0.top.equalTo(15)
        }
        
        mainStackView.addArrangedSubview(pokemonImageView)
        
        pokemonImageView.snp.makeConstraints {
            $0.width.equalTo(200)
            $0.height.equalTo(200)
        }
    }
}

// MARK: - Configuration
extension PokemonListCell {
    func configure(info: (name: String, imageUrl: String?)) {
        self.mainStackView.backgroundColor = UIColor.black.withAlphaComponent(0.2)
        self.titleLabel.text = info.name.uppercased()
        
        guard let urlString = info.imageUrl,
        let imageURL = URL(string: urlString) else { return }
        self.pokemonImageView.kf.setImage(with: imageURL, placeholder: #imageLiteral(resourceName: "pokemon-placeholder"))
        self.pokemonImageView.layer.cornerRadius = 10
    }
}
