//
//  PokemonListViewController.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation
import UIKit

class PokemonListViewController: AppController {
    
    var viewModel: PokemonListViewModel
    
    private lazy var filterTextField: UITextField = {
        let textField = UITextField(frame: CGRect(x: 0, y: 0, width: 150, height: 40))
        textField.delegate = self
        textField.placeholder = "  Search Pokemon"
        textField.autocorrectionType = UITextAutocorrectionType.no
        textField.keyboardType = UIKeyboardType.default
        textField.returnKeyType = UIReturnKeyType.done
        textField.clearButtonMode = UITextField.ViewMode.whileEditing
        textField.leftViewMode = UITextField.ViewMode.always
        textField.setLeftImage(imageName: "lupa")
        //textField.becomeFirstResponder()
        textField.addTarget(self, action: #selector(didChangeText(_:)), for: .editingChanged)
        return textField
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.registerCell(cellClass: PokemonListCell.self)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .white
        return tableView
    }()
    
    required init(viewModel: PokemonListViewModel) {
        self.viewModel = viewModel
        super.init()
        self.viewModel.delegate = self
        navigationItem.largeTitleDisplayMode = .always
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigation()
        configureLayout()
        viewModel.loadData()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
}

// MARK: UI Setup
private extension PokemonListViewController {
    
    func setupNavigation() {
        navigationItem.titleView = filterTextField
    }
    
    func configureLayout() {
        view.addSubview(tableView)
        tableView.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
    }
}

// MARK: Actions
private extension PokemonListViewController {
    @objc func didChangeText(_ sender: UITextField) {
        self.viewModel.filterByName(text: sender.text!)
    }
}

// MARK: UITableViewDataSource & UITableViewDelegate
extension PokemonListViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfItems
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeue(cellClass: PokemonListCell.self, indexPath: indexPath)
        cell.configure(info: viewModel.getInfo(for: indexPath))
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        viewModel.showDetail(indexPath: indexPath)
    }
}

// MARK: RequestDelegate
extension PokemonListViewController: RequestDelegate {
    func didUpdate(with state: ViewState) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            switch state {
            case .idle:
                self.startLoading()
                break
            case .loading:
                self.startLoading()
            case .success:
                self.tableView.setContentOffset(.zero, animated: true)
                self.tableView.reloadData()
                self.stopLoading()
            case .error(let error):
                self.stopLoading()
                self.present(error: error, customAction: UIAlertAction(title: "Try Again", style: .default, handler: { [weak self] _ in
                    guard self != nil else { return }
                    self!.viewModel.loadData()
                }))
            }
        }
    }
}

// MARK: UITextFieldDelegate
extension PokemonListViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
