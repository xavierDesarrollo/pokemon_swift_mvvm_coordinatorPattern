//
//  PokemonDetailViewController.swift
//  Pokedex
//
//  Created by Xavier Sotomayor on 8/3/24.
//

import Foundation
import UIKit
import SnapKit
import Kingfisher

class PokemonDetailViewController: AppController {
    
    var viewModel: PokemonDetailViewModel

    required init(viewModel: PokemonDetailViewModel) {
        self.viewModel = viewModel
        super.init()
        self.viewModel.delegate = self
        navigationItem.largeTitleDisplayMode = .always
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigation()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
}

// MARK: UI Setup
private extension PokemonDetailViewController {
    func setupNavigation() {
        self.view.backgroundColor = .white
        navigationItem.title = "\(viewModel.pokemon.name.uppercased())"
    }
}

// MARK: RequestDelegate
extension PokemonDetailViewController: RequestDelegate {
    func didUpdate(with state: ViewState) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            switch state {
            case .idle:
                self.startLoading()
                break
            case .loading:
                self.startLoading()
            case .success:
                
                self.stopLoading()
            case .error(let error):
                self.stopLoading()
                self.present(error: error, customAction: UIAlertAction(title: "Try Again", style: .default, handler: { [weak self] _ in
                    guard self != nil else { return }
                    
                }))
            }
        }
    }
}
